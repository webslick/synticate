<?
class Login_Model extends Models {
        public function auth( $data ) {
        $flag = false;
        $security = new Security();
        $valid = $security->valid_user( $data );
        
        if( isset( $valid['pass'] ) ) {            
            $email = $this->real_escape_string( $data['email'] );
            $pass = $this->real_escape_string( $data['pass'] );            
            $r = $this->query("
                SELECT 
                    `pass` 
                FROM 
                    `users` 
                WHERE 
                    `email`='$email' 
                LIMIT 0,1
            ")->fetch_assoc();
            
            if( isset( $r['pass'] ) ) {
                if( $security->verify_password( $data['pass'], $r['pass'] ) ) {
                    $key = md5( md5( $data['email'].md5( $r['pass'] ) ) );
                    $this->query("UPDATE `users` SET `key`='$key' WHERE `email`='$email'");
                    setcookie("auth_key", $key, time()+3600, "/" );
                    $_SESSION['auth_key'] = $key;
                    $flag = array('e'=>array('auth'));
                } else {
                    setcookie("auth_key", "", time()-3600, "/" );
                    unset( $_SESSION['auth_key'] );
                    $flag = array('e'=>array('err_pass'));
                }    
            } else {
                setcookie("auth_key", "", time()-3600, "/" );
                unset( $_SESSION['auth_key'] );
                $flag = array('e'=>array('err_pass'));
            }
        } else {
            setcookie("auth_key", "", time()-3600, "/" );
            unset( $_SESSION['auth_key'] );
            $flag = $valid;
        }        
        if( $data['exit'] == 1 ) {
            setcookie("auth_key", "", time()-3600, "/" );
            unset( $_SESSION['auth_key'] );
            $flag = array('e'=>array('exit'));
        }
        return json_encode( $flag, true );
    }
    //==============================================================================
    public function is_user() {
        if( isset( $_COOKIE['auth_key'] ) || isset( $_SESSION['auth_key'] ) ) {
            $key = $this->real_escape_string( $_SESSION['auth_key'] /*$_COOKIE['auth_key']*/ );
            $user = $this->query("
                SELECT * FROM 
                    `users` 
                WHERE 
                    `key`='$key'
                LIMIT 0,1
            ")->fetch_assoc();
            
            if( count( (array)$user ) > 0 ) {
                $access = array();
                switch( $user['access'] ) {
                    case 0:
                        $access = array( 'admin'=>$user );
                    break;
                    //=====
                    case 1:
                        $access = array( 'moder'=>$user );
                    break;
                    //=====
                    case 2:
                        $access = array( 'user'=>$user );
                    break;
                }
                return $access;
            } else {
                return 0;
            }
        } else {
            return 0;
        }
    }
    //==============================================================================
    //==============================================================================
    //==============================================================================
    //==============================================================================
    //==============================================================================
    //==============================================================================
    //==============================================================================
}
?>