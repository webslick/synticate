<!-- Head -->
<?php include ("include/head.php")?>

<!-- Header -->
<?php include ("include/header_main.php")?>

<!-- Main content -->	
<main class="content-main">	
    <h1 class="m-page-h1 dn">We would like to invite you to a magnificent art event. 
		Visionarium  art festival- provides  a ground where brightest artists come to 
		create, exhibit, teach and study together.</h1>
</main><!-- END Main content -->	

<!-- footer -->
<?php include ("include/footer.php")?>

