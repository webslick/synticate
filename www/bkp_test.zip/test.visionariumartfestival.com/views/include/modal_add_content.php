<div id="add_content_wrap" class="add-content-wrap win-modal-wrap fade-up" style="display:none">
	<div id="add_content" class="r-form win-modal">
		<span class="fa-close" onclick="javascript: $('#add_content_wrap').hide()" title="Закрыть"></span>
		<div class="r-form-title">Add content</div>
	
	
	</div>
</div>


<script>
	// Move modal window
	$(function() {
		$("#add_content").draggable();
	});
</script>
