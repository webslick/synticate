<div id="log_form_wrap" class="r-form-wrap win-modal-wrap fade-up" style="display:none">
	<div id="log_form" class="r-form win-modal">
		<span class="fa-close" onclick="javascript: $('#log_form_wrap').hide()" title="Закрыть"></span>
		<div class="r-form-title">Authorization</div>
	
		<div class="r-form-input">
			<input id="email" type="text" placeholder="E-mail">
		</div>
		<div class="r-form-input">
			<input id="pass" type="text" placeholder="Password">
		</div>
	
		<button id="login" class="r-form-btn">Log In</button>
		<div class="r-form-sign  flex sa">
			<a class="dn" href="">New user registration</a>
			<a href="">Forgot password?</a>
		</div>
		<img class="r-form-logo" src="/img/logo_small.png" alt="Logo">
	</div>
</div>


<script>
	// Move modal window
	/*$(function() {
		$("#log_form").draggable();
	});*/
</script>
