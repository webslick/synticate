<!-- Head -->
<?php include ("../include/head.php"); ?>

<!-- Header -->
<?php include ("../include/header_page.php"); ?>

<!-- Main content -->	
<main class="content-page animate third_bottom">		
    <h1 class="page-h1">Concept</h1>

	<!-- Articles List -->
	<section class="article-wrap flex sb">
		<!-- Article_1 -->
		<article class="article-item art-col-2">
			<h2>Festival Concept</h2> 
			<div class="art-img-block">
				<img src="/images/concept/concept_5.jpg">
			</div>	
			<div class="art-text-block">	
				<p>Visionarium Festival is a place where artists, decorators and creators come together to create, exhibit, 
					teach and study together on festival grounds.</p>
				<p>The concept is based on varied aspects of Visionary art.</p> 
				<p>In our days the Visionary art can be represented in multiple directions such as Digital art, 
					traditional painting on canvas, installations, sculptures, video, sound, VR worlds, and even holograms.</p>    
				<p>Our mission is to unite the most bright Visionary artists and manifest this great movement.</p>
				<p>Collaborate share the experience and reach higher levels in skills and techniques.</p>
			</div>
		</article>
		
		<!-- Article_2 -->
		<article class="article-item art-col-2">
			<h2>Our mission</h2> 
			<div class="art-img-block">
				<img src="/images/concept/concept_3.jpg">
			</div>	
			<div class="art-text-block">	
				<p>The festival area is based on crop circle concept, that unites visitors and artists and allows a constant flow
					of people in between the 3 main galleries, workshop area, market area, Cafes, tea shops, and Bar.</p>
				<p>In the center will be located the stage.</p>
			</div>
		</article>
		
		<!-- Article_3 -->
		<article class="article-item art-col-2">
			<h2>Music</h2> 
			<div class="art-img-block">
				<img src="/images/concept/concept_1.jpg">
			</div>	
			<div class="art-text-block">	
				<p>The music is an accompaniment for workshops, lectures, and art to happen.</p> 
				<p>It is there to create an ambient and calm creative atmosphere.  
					The musical concept will follow the line in such styles as Ethnic music, instrumental, 
					psy chill, ambient, psy Dab, downtempo Psybient.
					From 20.00-00.00 concerts and live performances, you may find on the Stage and around.</p>
			</div>
		</article>
		
		<!-- Article_4 -->
		<article class="article-item art-col-2">
			<h2>Workshops</h2> 
			<div class="art-img-block">
				<img src="/images/concept/concept_4.jpg">
			</div>	
			<div class="art-text-block">	
				<p>We will try to surprise you, with unique performances, Artistic costumes, 
					magicians and the sound of real soul voices. In the workshop area, you can find the most
					interesting program.<p> 
				<p>There will be given different art workshops and unique techniques, pottery, art Lessons,
					presentation of year study programs at different art schools and Academies.</p>
				<p>Live art painting and Body art.</p>
			</div>
		</article>
		
		<!-- Article_4 -->
		<article class="article-item art-col-2">
			<h2>The festival area</h2> 
			<div class="art-img-block">
				<img src="/images/concept/concept_6.jpg">
			</div>	
			<div class="art-text-block">	
				<p>The festival area is based on crop circle concept, that unites visitors and artists and allows a constant flow of people in between the 3 main galleries, workshop area, market area, Cafes, tea shops, and Bar.
				In the center will be located the stage. 
				</p>
			</div>
		</article>
	</section><!-- END Articles List -->

</main><!-- END Main content -->



<!-- footer -->
<?php include ("../include/footer.php"); ?>