	<footer>
		<div class="footer-wrap tc">
			<span class="footer-contact">
				<a class="f-contact-btn" href="/page/contact.php">Contact</a>
			</span>
		</div>			
	</footer>
		
	<!-- Timer -->
	<div class="timer-to eTimer"></div>
	
	<!-- Background iamage -->
	<div id="bg_fixed" class="bg-img-wrap c-page" data-speed="5" data-type="background">
		<img class="main-bg-img" src="/img/bg-full.jpg" alt="Visionarium">
	</div>
	
<!-- Таймер обратного отсчета -->
<script src="https://e-timer.ru/js/etimer.js"></script>	
	
</body>
</html>