<div id="add_content_wrap" class="win-modal-wrap fade-up" style="display:none">
	<div id="add_content" class="admin-modal win-modal">
		<span class="fa-close" onclick="javascript: $('#add_content_wrap').hide()" title="Закрыть"></span>
		<span class="modal-tips tip-err">Data Error</span>
		<div class="admin-modal-title">Add content</div>
		<div class="admin-modal-content">
			<div class="content-type flex">
				<span class="c-sign">Select content type</span>
				<!-- Content 1 col -->
				<input id="col_1" class="c-inp" type="radio" name="col" hidden>
				<label class="c-type col-type-1" for="col_1" title="Контент в одну колонку"></label>
				<!-- Content 2 cols -->
				<input id="col_2" class="c-inp" type="radio" name="col" hidden>
				<label class="c-type col-type-2" for="col_2" title="Контент в две колонки"></label>
			</div>
			<div class="content-title-wrap flex sb">
				<!-- Content Title -->
				<div class="content-title">
					<input class="c-title" type="text" placeholder="Enter title">
				</div>
				<div class="content-publ">
					<span class="tips-wrap">
						<span class="tips-text">
							<p>To post content, check this box.</p>
						</span>
					</span>
					<input id="r_box" class="root-box" type="checkbox" hidden>
					<label class="root-label" for="r_box">Published</label>
				</div>
			</div>
			<div class="col-img-1 content-img">
				<img class="dn r" src="" alt="Image">
				<span class="load-img-title">Add image  1200 x 600 px</span>
			</div>
			<div class="col-img-2 content-img">
				<img class="dn" src="" alt="Image">
				<span class="load-img-title">Add image  800 x 450 px</span>
			</div>
			<div class="content-text-wrap">
				<textarea name="" rows="8" placeholder="Description text"></textarea>
			</div>
			<div class="tr">
				<span class="save-btn">Save <b class="fa-floppy-o"></b></span>
			</div>
		</div>	
	</div>	
</div>


<script>
	// Move modal window
	$(function() {
		$("#add_content").draggable();
	});
</script>
