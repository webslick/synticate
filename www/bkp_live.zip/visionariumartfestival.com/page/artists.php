<!-- Head -->
<?php include ("../include/head.php")?>

<!-- Header -->
<?php include ("../include/header_page.php")?>

<!-- Main content -->	
<main class="content-page animate third_bottom">
	<h1 class="page-h1">Artists</h1>
	
	<!-- Section 1 -->
	<section class="article-wrap flex sb col-1 rise block-up">
		<!-- Big ban_1 -->
		<article class="article-item art-col-1">
			<div class="flex sb">
				<h2>Deco</h2>
				<!-- admin-menu -->
				<?php include ("../include/admin_menu.php")?>
			</div> 
			<div class="art-video-block">
				<iframe width="100%" height="400" src="https://www.youtube.com/embed/697gn5siC_Q" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
			</div>	
			<div class="art-text-block">	
				<p>Decorations in all the festival areas will be made by Ihtianderson 
					in Collaboration with Centaurus Fractals and Quantum tribe. 
					These artists collaborate not for the first time, Ihtianderoson
					and Centaurus already 5 years collaborate in big festival projects. 
					You can find some more information and see how this collaboration
					look like in the video below.</p>
			</div>
		</article>						
		<!-- Artist_1 -->
		<article class="article-item art-col-2">			
			<div class="flex sb">
				<h2>Quantum tribe</h2>
				<!-- admin-menu -->
				<?php include ("../include/admin_menu.php")?>
			</div> 
			<div class="art-img-block">
				<img src="/images/artists/Quantum-tribe-deco.jpg">
			</div>	
			<div class="art-text-block">	
				<p>Quantum tribe - a team of active creative people who share similar world-views, 
					the desire for self-knowledge and self-development. In terms of activities, 
					Quantum tribe community is a very multi-functional organization, covering 
					various areas. We organize events, exhibitions, festivals in Russia and abroad,
					as well as creative implementations in the field of visual installations and decorations.</p>
			</div>
		</article>
		<!-- Artist_2 -->
		<article class="article-item art-col-2">
			<div class="flex sb">
				<h2>Centaurus</h2>
				<!-- admin-menu -->
				<?php include ("../include/admin_menu.php")?>
			</div>  
			<div class="art-img-block">
				<img src="/images/artists/Centaurus.jpg">
			</div>	
			<div class="art-text-block">	
				<p>Centaurus - String Art Artist</p>
			</div>
		</article>
		<!-- Artist_3 -->	
		<article class="article-item art-col-2">
			<div class="flex sb">
				<h2>Ihti Anderson</h2>
				<!-- admin-menu -->
				<?php include ("../include/admin_menu.php")?>
			</div>  
			<div class="art-img-block">
				<img src="/images/artists/Ihtianderson_teem.jpg">
			</div>	
			<div id="full_text_3" class="art-text-block ">
				<div class="text-block">
					<p>Yuri and his wife Revital started as Decorators in 2007, at the scenery for psychedelic music parties. 
					During last years Ihtiandreson team come up with some completely new technics, using mainly stretchable 
					and half transparent textiles pained with an airbrush. They manage to create huge layered mandala canopies 									installations, that have a unique and artistic look due to profound depth, to 3d shapes and transparency 
					effects. This and other deco inventions of the Ihtianderson Team was fresh and even revolutionary new for 
					most of the events were the team was participated. So you can definitely expect more surprising invasions 
					and deco solutions from this team.</p>
				</div>
				<div class="to-gallery flex sb">
					<span class="show-text-btn" onClick="javascript:show_content ('full_text_3','add','show')">Full text <b class="fa-angle-right"></b></span>
					<a class="to-gallery-btn" href="/artist_gallery/gallery_ihtianderson.php" title="Go to this Artist gallery">Watch the gallery <b class="fa-angle-right"></b></a>
				</div>
			</div>
		</article>		
		<!-- Big ban_2 -->
		<article class="article-item art-col-1">
			<div class="flex sb">
				<h2>Digital vision domo</h2>
				<!-- admin-menu -->
				<?php include ("../include/admin_menu.php")?>
			</div>			 
			<div class="art-img-block">
				<img src="/images/artists/Digital-Vision-DOMO.jpg">
			</div>	
			<div class="art-text-block">	
				<p>Experimental floor Interactive 360, Virtual reality, Hologram, live sculpting will be
					presented to the Audience in the Visual Domo gusts are welcome to try
					and travel in the virtual worlds and experience the scene.Hybrid Project - Works with Hologram,
					360 mapping and VR</p>
			</div>
		</article>							
		<!-- Artist_4 -->
		<article class="article-item art-col-2">
			<div class="flex sb">
				<h2>Julius Horsthuis</h2>
				<!-- admin-menu -->
				<?php include ("../include/admin_menu.php")?>
			</div> 
			<div class="art-img-block">
				<img src="/images/artists/artist_2.jpg">
			</div>	
			<div class="art-text-block">	
				<p>Specialize in fractals animations and VR</p>
			</div>
		</article>
		<!-- Artist_5 -->
		<article class="article-item art-col-2">
			<div class="flex sb">
				<h2>Natural Warp - Digital art, 360 VR</h2>
				<!-- admin-menu -->
				<?php include ("../include/admin_menu.php")?>
			</div>			 
			<div class="art-img-block">
				<img src="/images/artists/Natural-warp.jpg">
			</div>	
			<div id="full_text_5" class="art-text-block">
				<div class="text-block">	
					<p>My latest work is the result of an attempt to translate the never-ending depths hiding
						not even a fraction of a millimeter behind the curtain of our everyday reality... 
						It is an attempt to build a bridge between any concept observable in this world and
						the unimaginable world of dreams behind it on the other side, to provide a panorama
						over that landscape that stretches over countless of the inter-dimensional facets of it,
						a view we can only dream of to perceive. It is an invitation to the mind of the observer
						to - for just a moment - feel the fractal nature of the now, to inspire awe for the
						multi-layered detail fractalizing itself into the architecture of the moment, 
						to try and connect with its deep design within and to dive into that overwhelming experience.</p>
				</div>
				<div class="to-gallery flex sb">
					<span class="show-text-btn" onClick="javascript:show_content ('full_text_5','add','show')">Full text <b class="fa-angle-right"></b></span>
				</div>
			</div>
		</article>		
		<!-- Artist_6 -->
		<article class="article-item art-col-2">
			<div class="flex sb">
				<h2>Luminokaya - 3D sculpting, Digital art, VR</h2>
				<!-- admin-menu -->
				<?php include ("../include/admin_menu.php")?>
			</div>			 
			<div class="art-img-block">
				<img src="/images/artists/Luminokaya.jpg">
			</div>	
			<div class="art-text-block">	
				<p>Luminokaya - Talented Russian Digital  Artist. Has over 20 years of experience in different styles of
					art Well known by his unique technique, creating a digital world in cinema4D, VR or using many others
					programs creating digital live sculpting projections.</p>
			</div>
			<div class="to-gallery">
				<a class="to-gallery-btn" href="/artist_gallery/gallery_luminokaya.php" title="Go to this Artist gallery">Watch the gallery <b class="fa-angle-right"></b></a>
			</div>
		</article>				
		<!-- Artist_7 -->
		<article class="article-item art-col-2">			
			<div class="flex sb">
				<h2>Hybrid Project</h2>
				<!-- admin-menu -->
				<?php include ("../include/admin_menu.php")?>
			</div> 
			<div class="art-img-block">
				<img src="/images/artists/Hybird-Progect.jpg">
			</div>	
			<div class="art-text-block">	
				<p>Hybrid Project - Works with Hologram,<br>
					360 mapping and VR</p>
			</div>
			<div class="to-gallery">
				<a class="to-gallery-btn" href="/artist_gallery/gallery_mathieu.php" title="Go to this Artist gallery">Watch the gallery <b class="fa-angle-right"></b></a>
			</div>
		</article> 
		<!-- Big ban_3 -->
		<article class="article-item art-col-1">
			<h2>Visionary art Domo</h2> 
			<div class="art-img-block">
				<img src="/images/artists/VIsionary-art-Domo.jpg">
			</div>	
			<div class="art-text-block">	
				<p>In the Visionary art Domo, you can find more traditional techniques like Oil or
					Acryl on canvas original artworks. Representatives of Visionary Realism, 
					Surrealism, Tribal, and Ornamental Art.</p>
			</div>
		</article>				
		<!-- Artist_8 -->
		<article class="article-item art-col-2">
			<h2>Ihtianderson</h2> 
			<div class="art-img-block">
				<img src="/images/artists/Ihtianderson-Deco2.jpg">
			</div>	
			<div class="art-text-block">	
				<p>Ihtianderson - the Painter, specialize in UV large scale Backdrops, OIL,
					and Acrylic on canvases, Digital art , 3D art  and Decorations</p>
			</div>
			<div class="to-gallery">
				<a class="to-gallery-btn" href="/artist_gallery/gallery_ihtianderson.php" title="Go to this Artist gallery">Watch the gallery <b class="fa-angle-right"></b></a>
			</div>
		</article>	
		<!-- Artist_9 -->
		<article class="article-item art-col-2">
			<h2>Laurence Caruana</h2> 
			<div class="art-img-block">
				<img src="/images/artists/laurence-Caruana.jpg">
			</div>	
			<div id="full_text_9" class="art-text-block">
				<div class="text-block">	
					<p>Laurence Caruana - Painter, writer and the director of the Vienna Visionary Art Academy.  
						As an artist, author and teacher, Laurence Caruana have inspired hundreds of students
						to see and explore new aspects of their vision. With a passionate interest in Old Masters’ 
						techniques and the Alchemy of Painting, he brings new depths of understanding to the artist’s 
						quest for beauty, harmony and sacred expression in paint.</p>
				</div>
				<div class="to-gallery flex sb">
					<span class="show-text-btn" onClick="javascript:show_content ('full_text_9','add','show')">Full text <b class="fa-angle-right"></b></span>
				</div>
			</div>
		</article>		
		<!-- Artist_10 -->
		<article class="article-item art-col-2">
			<h2>Robert Venosa</h2> 
			<div class="art-img-block">
				<img src="/images/artists/Robert-Venossa.jpg">
			</div>	
			<div id="full_text_10" class="art-text-block">
				<div class="text-block">	
					<p>Robert Venosa (January 21, 1936 – August 9, 2011) was an American artist who resided in Boulder, Colorado, USA.
						He studied with what are termed the New Masters. His artworks reside in collections around the world.
						He first studied under Mati Klarwein in New York. Venosa move to Europe and studied with one of the 
						founders of the Fantastic Realist movement, Ernst Fuchs (artist).rom these masters he learned variations
						of a venerated painting technique developed in the mid 1400's called the Mische Technique which involves
						underpainting in water soluble tempera with transparent oil paint glazes...</p>
				</div>
				<div class="to-gallery flex sb">
					<span class="show-text-btn" onClick="javascript:show_content ('full_text_10','add','show')">Full text <b class="fa-angle-right"></b></span>
				</div>
			</div>
		</article>
		<!-- Artist_11 -->
		<article class="article-item art-col-2">
			<h2>Nita Kravets</h2> 
			<div class="art-img-block">
				<img src="/images/artists/Nita_Kravets_FluRAnet_project.jpg">
			</div>
			<div id="full_text_11" class="art-text-block">
				<div class="text-block">				 	
					<p>FluRAnet project - Created by Nita Kravets and Rukavitzen Sergey In March 2000. 
						They were the first Decoration leading team that time Inspiring a great UV 
						movement in Ukraine. Starting from Classical painting, portraits, landscapes 
						with classical materials — oil pastels, watercolors. Passionate about colored 
						pencils and fluorescent pastels. Developed the author's technique on 
						canvas-layered painting with scraping fluorescent oil. 
						As well as painting with UV Acrylic on Black tissue. 
						Lately passionate about UV oil/ Acrylic and Doll design
						made from paper clay. Fluranet</p>
				</div>
				<div class="to-gallery flex sb">
					<span class="show-text-btn" onClick="javascript:show_content ('full_text_11','add','show')">Full text <b class="fa-angle-right"></b></span>
				</div>
			</div>				
		</article>
		<!-- Artist_12 -->
		<article class="article-item art-col-2">
			<h2>Julien Lechelle - sculptures</h2> 
			<div class="art-img-block">
				<img src="/images/artists/Julien-Lechelle.jpg">
			</div>	
			<div id="full_text_12" class="art-text-block">
				<div class="text-block">	
					<p>Julien Lechelle is a french artist, works wood and steel, to create handmade's and infinitely 
						modular's sculptures, inspired by natural shapes and imaginary representations. He quickly 
						expressed interest in free outdoor's installation, ike natural or abandoned places, 
						and add it various illumination's techniques by night. By mixing string-art, land-art,
						and recently light-painting, he tries with photography to create illusion of organic 
						and hybrid species observed in natural habitat. He brings on festival his «Protéus» 
						sculpture and his new «Géonésys» sculpture, thanks to their integrated 
						night show, should mesmerize you after nightfall.</p>
				</div>
				<div class="to-gallery flex sb">
					<span class="show-text-btn" onClick="javascript:show_content ('full_text_12','add','show')">Full text <b class="fa-angle-right"></b></span>
					<a class="to-gallery-btn" href="/artist_gallery/gallery_lechelle.php" title="Go to this Artist gallery">Watch the gallery <b class="fa-angle-right"></b></a>
				</div>
			</div>
		</article>
		<!-- Artist_13 -->
		<article class="article-item art-col-2">
			<h2>Andrey Averin - Shiva om art</h2> 
			<div class="art-img-block">
				<img src="/images/artists/Shiva_om_art.jpg">
			</div>	
			<div id="full_text_13" class="art-text-block">
				<div class="text-block">	
					<p>Digital & Visionarity artist - Averin Andrey aka Shiva Om from Ukraine.
						Andrey Averin - born 16.09.1980 Since 2003, Andrey created music in psychedelic 
						trance style and organized parties and festivals in Ukraine and other countries. 
						One of the most famous projects is - shiva om. In 2012, Andrey aka ShivaOm opens 
						his artistic and started creating artworks in DIGITAL & VISIONARY & SHAMANIC ART concept. 
						After receiving good reviews in 2012, Andrey with a friend and partner musician Sergei 
						Grigoriadi, produce the first collection of Shiva Om Art clothing and present it to the world. 
						In 2015 start with his personal project - UV art prints and Symmetry Vision.
						The symmetry of dimensions is a separate aspect in the world of Digital & Visionary Art. 
						This subspecies shows the layered structure of the universe and created to guide the viewer's 
						consciousness to its center.</p>
				</div>
				<div class="to-gallery flex sb">
					<span class="show-text-btn" onClick="javascript:show_content ('full_text_13','add','show')">Full text <b class="fa-angle-right"></b></span>
				</div>
			</div>
		</article>
		<!-- Artist_14 -->	
		<article class="article-item art-col-2">
			<h2>Jeff Drawbot</h2> 
			<div class="art-img-block">
				<img src="/images/artists/Jeff_Drawbot.jpg">
			</div>
			<div id="full_text_14" class="art-text-block">
				<div class="text-block">
					<p>Jeff is a visionary artist from France, self-taught since 2000 in graphic design, he been also formed, 
						during the study in Movie realization, Game design and Comics draw. After having worked in video 
						games companies, he found pleasure to confront this graphic of game approach with his spiritual, 
						psychedelic and shamanic experience. He likes to play with the impalpable of the spiritual world 
						and with new technology, and it is in this direction that he has prioritized the use of digital 
						media and 3D. He starts to create in 2013 to do visionary art, mixing the representative 
						body & the abstract visions. He changes its artist name to Jeff Drawbot in 2018 to be more 
						related with he’s universe and workflow.</p>
				</div>				
				<div class="to-gallery flex sb">
					<span class="show-text-btn" onClick="javascript:show_content ('full_text_14','add','show')">Full text <b class="fa-angle-right"></b></span>
					<a class="to-gallery-btn" href="/artist_gallery/gallery_drawbot.php" title="Go to this Artist gallery">Watch the gallery <b class="fa-angle-right"></b></a>
				</div>
			</div>
		</article> 		
		<!-- Artist_15 -->
		<article class="article-item art-col-2">
			<h2>Martina Hofman</h2> 
			<div class="art-img-block">
				<img src="/images/artists/Martina-Hofman.jpg">
			</div>	
			<div id="full_text_15" class="art-text-block">
				<div class="text-block">	
					<p>German-born, Martina Hoffmann partially grew up in Cameroon, West Africa.
						She studied art education with Professor Kiefer (father of Anselm Kiefer) 
						and sculpting with Professor Spelmann at the Johann Wolfgang Goethe University in Frankfurt/Main, Germany.
						During this time she also met the Fantastic Realist, Robert Venosa, and greatly inspired by his work, 
						began her work as a painter. During their 30 year relationship they closely worked together, 
						taught workshops worldwide and shared studios, both in the US as well as in Europe. 
						Today Martina Hoffmann works as a painter and sculptress and remains a central figure
						in contemporary Visionary Art.</p>
				</div>
				<div class="to-gallery flex sb">
					<span class="show-text-btn" onClick="javascript:show_content ('full_text_15','add','show')">Full text <b class="fa-angle-right"></b></span>
					<a class="to-gallery-btn" href="/artist_gallery/gallery_hoffman.php" title="Go to this Artist gallery">Watch the gallery <b class="fa-angle-right"></b></a>
				</div>
			</div>
		</article>
		<!-- Artist_16 -->
		<article class="article-item art-col-2">
			<h2>Evgenia Silvina</h2> 
			<div class="art-img-block">
				<img src="/images/artists/Evgenia-Silvina.jpg">
			</div>	
			<div id="full_text_16" class="art-text-block">
				<div class="text-block">	
					<p>Evgenia Silvina - Born in Russia and raised in UAE graduated Art Academy in Poland.
						Ever since then life circumstances brought me in contact with art and whenever I found
						myself going “off- course” some greater power would bring me back on my path as an artist.
						I celebrate women through art: their extraordinary expression of self, their mystery, and strong spirit.
						I treasure and seek in my subjects that courage to be authentic, that powerful personality that stands
						out from a herd I seek new feminine archetype. Evgenia is new tribal visionary Artist, has a note of
						Gustav Klimt in her works. Reach Gold shins in her works in contrast with monochrome.</p>
				</div>
				<div class="to-gallery flex sb">
					<span class="show-text-btn" onClick="javascript:show_content ('full_text_16','add','show')">Full text <b class="fa-angle-right"></b></span>
					<a class="to-gallery-btn" href="/artist_gallery/gallery_silvina.php" title="Go to this Artist gallery">Watch the gallery <b class="fa-angle-right"></b></a>
				</div>
			</div>
		</article>
		<!-- Artist_17 -->
		<article class="article-item art-col-2">
			<h2>Subliquida - graphic art</h2> 
			<div class="art-img-block">
				<img src="/images/artists/Subliquida.jpg">
			</div>	
			<div id="full_text_17" class="art-text-block">
				<div class="text-block">	
					<p>Andrea Baiardo aka Subliquida is a self-taught artist, entomology maniac, 
						curiosities collector, plants lover, and passionate gardener. 
						His style is clearly inspired by the greatest Masters in engraving and etching, 
						matched with a very fluid research in shapes and textures of the greatest artist 
						of all times, Mother Nature, and sincerely stimulated by the psychedelic experience; 
						indeed through his drawings, he can bring out the link between scientific 
						knowledge and expanding consciousness.</p>
				</div>			
				<div class="to-gallery flex sb">
					<span class="show-text-btn" onClick="javascript:show_content ('full_text_17','add','show')">Full text <b class="fa-angle-right"></b></span>
					<a class="to-gallery-btn" href="/artist_gallery/gallery_subliquida.php" title="Go to this Artist gallery">Watch the gallery <b class="fa-angle-right"></b></a>
				</div>
			</div>
		</article>
		<!-- Artist_18 -->
		<article class="article-item art-col-2">
			<h2>Helena Arturaleza</h2> 
			<div class="art-img-block">
				<img src="/images/artists/Helena_Arturalesa.jpg">
			</div>	
			<div id="full_text_18" class="art-text-block">
				<div class="text-block">	
					<p>Helena was born in 1992 in a little village just north of Amsterdam. She has always been
						a creative spirit; since childhood, she found her ways to express through dance, music, 
						and painting. Her artistic journey started at age 19 when she was asked to teach Art 
						to her peers during her Media & Design education. Besides she started to receive her 
						first commissions. As a result she skipped art school and started her life as a 
						professional artist. With the world as her teacher, she embraced life as a traveler, 
						developed her own style and taught herself how to paint. After several years of life 
						experience she studied with different artists at the Vienna Academy of Visionary art 
						Helena Arturaleza.</p>
				</div>
				<div class="to-gallery flex sb">
					<span class="show-text-btn" onClick="javascript:show_content ('full_text_18','add','show')">Full text <b class="fa-angle-right"></b></span>
					<a class="to-gallery-btn" href="/artist_gallery/gallery_arturaleza.php" title="Go to this Artist gallery">Watch the gallery <b class="fa-angle-right"></b></a>
				</div>
			</div>
		</article>
		<!-- Artist_19 -->
		<article class="article-item art-col-2">
			<h2>Joaquin Vila</h2> 
			<div class="art-img-block">
				<img src="/images/artists/Joaquin_Vila.jpg">
			</div>	
			<div id="full_text_19" class="art-text-block">
				<div class="text-block">	
					<p>Joaquín Vila, Madrid, España 1980.</p>
					<p>He is a visual artist, illustrator, and muralist owning a Bachelor of Fine Arts in
					Scenography and is Postgraduate in Exhibition design. His artistic career is governed 
					by the constant investigation of the relationship between art and nature.
					He has developed his artistic work especially through paper drawings transposed 
					into large-scale murals, occasionally using other resources.
					His personal works represent the union between humans and nature through hybrid 
					beings, half human, half plants or half animals. They refer to the non-material 
					nature, representing life beyond the physical, that which is not seen. It also 
					shows in symbolic elements, glyphs, and patterns of different cultures and 
					spiritual paths, alluding to the syncretism of the 21st century, creating a code 
					of visual language that refers to the essence of all of them. In his work on a paper, 
					he uses mainly graphite pencils, permanent inks, and white ink. He also uses acrylic 
					and enamel paints when he works on other supports such as canvas or wood and wall paint, 
					enamels or sprays when he works on large-scale walls.
					Currently lives and works in Madrid.</p>
				</div>
				<div class="to-gallery flex sb">
					<span class="show-text-btn" onClick="javascript:show_content ('full_text_19','add','show')">Full text <b class="fa-angle-right"></b></span>
				</div>
			</div>
		</article>		
		<!-- Artist_20 -->
		<article class="article-item art-col-2">
			<h2>Liba Waring Stambollion</h2> 
			<div class="art-img-block">
				<img src="/images/artists/Pineal.jpg">
			</div>	
			<div id="full_text_20" class="art-text-block">
				<div class="text-block">	
					<p>Liba was born to American parents but grew up in South East Asia. She moved to the USA in her teenage years
						and currently lives in Paris France.
						She did a year of art and environmental studies at Simons Rock of Bard College and went on to receive a 
						scholarship from the School of the Art Institute of Chicago where she studied painting, woodworking and bookbinding.
						She graduated in 1988 and stayed in Chicago exhibiting, teaching art and working for a cabinet maker until she was 
						swept off her feet by a handsome and charming Frenchman. Today they have two sons and a company - Matahati which 
						employs a network of artisans to hand make their designs in recycled and renewable materials.
						Liba has been living in Paris since 1993 where she paints, writes, makes books, curates and designs furniture.
						Ecology, erotica and the sacred are the recurrent themes in her work.
						Liba and her husband have designed furniture for prestigious customers such as AVEDA body Shops, Thiou Restaurants, 						
						Marriot Hotel, Royalty from Bahrain, and many clients in the music and movie industry. She is a co-founder and 
						president of Matahati.
						Liba is the founder of Dreams and Divinities, a project which unites International visionary, fantastic and
						surrealist artists in the name of community and Love. The project showcases an eclectic mix of creativity through 
						a series of books and exhibits in prestigious sites and museums.
						She was head of AOI Europe (Art of Imagination founded in 1961)for a short time but stepped down and is now 
						independantly helping them curate.
						She has been an administrator on various Ning community including The Visionary Art Gallery and surrealism Now.
						Liba's has done almost 100 exhibitions worldwide. She has exhibited her paintings in both galleries and museums in 							
						Europe, Canada, USA, South and Central America, Asia and Australia.​
						Her furniture designs, poems, paintings and interviews have been featured on television, in newspapers, magazines, 							
						books & numerous articles online.</p>
				</div>
				<div class="to-gallery flex sb">
					<span class="show-text-btn" onClick="javascript:show_content ('full_text_20','add','show')">Full text <b class="fa-angle-right"></b></span>
					<a class="to-gallery-btn" href="/artist_gallery/gallery_liba_waring.php" title="Go to this Artist gallery">Watch the gallery <b class="fa-angle-right"></b></a>
				</div>
			</div>
		</article>
		<!-- Artist_21 -->
		<article class="article-item art-col-2">
			<h2>Emma Watkinson</h2> 
			<div class="art-img-block">
				<img src="/images/artists/Emma-Watkinson.jpg">
			</div>	
			<div id="full_text_21" class="art-text-block">
				<div class="text-block">	
					<p>Emma was born on Dartmoor, Devon close to Scorhill stone circle on Beltane May 1st 1973. After completing a Diploma in
						Fine Art & Design she spent many years traveling exploring the spiritual traditions & politics of different 								
						cultures, living in Thailand, New Zealand, Egypt, Israel, & California.
						Her inspiration comes principally from her explorations in consciousness and her personal journey of healing.
						Meditating deeply on mythology, & immersing herself in esoteric study, she seeks to create archetypal images that
						unlock portals in the psyche. She has a lifelong connection with the Druid path, spent time meditating with the 							
						Triratna Buddhist order, trained in Aikido & has studied with a Kabbalistic lineage. She is also interested in 
						psychology & healing. Her art has been exhibited widely at festivals, gallerys & museums around the world. 
						Initially self taught, researching classical Academy methods of painting, she had some experience assisting 
						Ernst Fuchs (principle founder of Fantastic Realism) in 2012 in Vienna , trained on courses in mische technique
						oil painting in Italy & Austria, & attended workshops at the London School of Representational Art.
						She has had some interesting challenges in her life, born with a disability ,she underwent a lot of surgery as
						a child and adult to enable her to walk. She views this challenge & the associated difficultys to be her greatest
						hurdle and teacher, instrumental in getting her on the path of self enquiry, healing & transformation.
						Creativity & her Art is part of this therapeutic process & spiritual practice.
						Besides Art, her other great love is Music & songwriting, jamming & playing flute, 
						singing & composing ambient soundscapes.</p>
				</div>
				<div class="to-gallery flex sb">
					<span class="show-text-btn" onClick="javascript:show_content ('full_text_21','add','show')">Full text <b class="fa-angle-right"></b></span>
					<a class="to-gallery-btn" href="/artist_gallery/gallery_watkinson.php" title="Go to this Artist gallery">Watch the gallery <b class="fa-angle-right"></b></a>
				</div>
			</div>
		</article>
		<!-- Artist_22 -->
		<article class="article-item art-col-2">
			<h2>Pineal Visions</h2> 
			<div class="art-img-block">
				<img src="/images/artists/Pineal.jpg">
			</div>	
			<div id="full_text_22" class="art-text-block">
				<div class="text-block">	
					<p>Pineal is a digital artist from the UK. He was Born in 1986 in Tehran-Iran. In 2002 he traveled 
						to India, and in 2006 to the UK. He was fascinated by the psychedelic culture in Goa, and after 
						having a profound mystical experience he started entering the visionary realms. His art expresses 
						the spiritual mysteries and is inspired by the inner realities within the Psyche. 
						Ancient symbolism and sacred geometry can be seen throughout his works, 
						as a way of communicating to the unconscious mind.</p>
				<div class="to-gallery flex sb">
					<span class="show-text-btn" onClick="javascript:show_content ('full_text_22','add','show')">Full text <b class="fa-angle-right"></b></span>
					<a class="to-gallery-btn" href="/artist_gallery/gallery_pineal.php" title="Go to this Artist gallery">Watch the gallery <b class="fa-angle-right"></b></a>	
				</div>
			</div>
		</article>	
		<!-- Big ban_4 -->
		<article class="article-item art-col-1">
			<h2>UV forest gallery</h2> 
			<div class="art-img-block">
				<img src="/images/artists/UV-forest-gallery.jpg">
			</div>	
			<div class="art-text-block">	
				<p>Large-scale fluorescent 3D Backdrops create a fiery tail and a unique atmosphere out
					of time and space - a UV forest gallery will be completed by large scale string art 
					fractals made by Centaurus fractals and some of Ihtiandersons mandala canopys.</p>
			</div>
		</article>						
		<!-- Artist_23 -->
		<article class="article-item art-col-2">
			<h2>Andrey Pronin</h2> 
			<div class="art-img-block">
				<img src="/images/artists/Pronin.jpg">
			</div>	
			<div class="art-text-block">	
				<p>Pronin - UV painter, Specialize in Large scale Backdrops</p>
			</div>
			<div class="to-gallery">
				<a class="to-gallery-btn" href="/artist_gallery/gallery_pronin.php" title="Go to this Artist gallery">Watch the gallery <b class="fa-angle-right"></b></a>
			</div>
		</article>
		<!-- Artist_24 -->
		<article class="article-item art-col-2">
			<h2>Trootootoo</h2> 
			<div class="art-img-block">
				<img src="/images/artists/TrooTooToo.jpg">
			</div>	
			<div class="art-text-block">	
				<p>Trootootoo - UV Painter, specialize in large-scale Backdrops on Black tissue</p>
			</div>
			<div class="to-gallery">
				<a class="to-gallery-btn" href="/artist_gallery/gallery_trootootoo.php" title="Go to this Artist gallery">Watch the gallery <b class="fa-angle-right"></b></a>
			</div>
		</article> 
		<!-- Artist_25 -->
		<article class="article-item art-col-2">
			<h2>Ihti Anderson</h2> 
			<div class="art-img-block">
				<img src="/images/artists/Ihtianderson_UV.jpg">
			</div>	
			<div class="art-text-block">	
				<p>The Ihtianderson project aside from decorations was specializing in UV large scale Backdrops,
					OIL and Acrylic painting on canvases, Digital art and 3D art.
					In visionary art gallery and in Uv forest gallery at Visionarium 
					festival grounds you will be able to find his original artworks from
					Ihtianderson created on different media and variety of techniques...</p>
			</div>
		</article>
		<!-- Artist_26 -->
		<article class="article-item art-col-2">
			<h2>Dimorphic</h2> 
			<div class="art-img-block">
				<img src="/images/artists/Dmitry-Dimorphic.jpg">
			</div>	
			<div class="art-text-block">	
				<p>Dimorphic - specialize in painting on Large-scale Backdrops on Black tissue</p>
			</div>
			<div class="to-gallery">
				<a class="to-gallery-btn" href="/artist_gallery/gallery_dimorphic.php" title="Go to this Artist gallery">Watch the gallery <b class="fa-angle-right"></b></a>
			</div>
		</article>
		<!-- Artist_27 -->	
		<article class="article-item art-col-2">
			<h2>Gumiho Anderson</h2> 
			<div class="art-img-block">
				<img src="/images/artists/Gumiho-Anderson.jpg">
			</div>	
			<div class="art-text-block">	
				<p>Gumiho Anderson - Focus in painting on Black tissue using Metallic, phosphoric and UV pains, 
					Acrylic and Oil painting on Canvas,  hot Batik technique and Decorations.</p>
			</div>
		</article>
		<!-- Artist_28 -->
		<article class="article-item art-col-2">
			<h2>Kshetra - Katya Shevchenko</h2> 
			<div class="art-img-block">
				<img src="/images/artists/WaterMan.jpg">
			</div>	
			<div id="full_text_28" class="art-text-block">
				<div class="text-block">	
					<p>Katya Shevchenko born in Ukraine, in a picturesque place near Kharkov. As a child, 
						she loved to be in the magic of the end of the world of nature and draw, nothing more. 
						She felt a full fairytale until I matured. She plunged into the deep world of sounds and music. 
						After graduating from an architectural university, I became acquainted with the subtle 
						language of architecture and, in particular, sacred geometry. My understanding of the 
						world has a different, deeper meaning. 
						Inspired by famous artists of Visionary, I begin to draw my first drawings on clothes, 
						I fill my hand and open up new possibilities for the interaction of fluorescent paint, 
						light, and fabric. For a long time, experiments and searches are generated.</p>
	
					<p>Own drawing technique, it gives you the opportunity to go ahead and move on to large 
						canvases and canvases. Now, together with talented designers, I am working on creating 
						exclusive non-standard clothing, an important element in which will be hand-painted.</p>
				</div>
				<div class="to-gallery flex sb">
					<span class="show-text-btn" onClick="javascript:show_content ('full_text_28','add','show')">Full text <b class="fa-angle-right"></b></span>
					<a class="to-gallery-btn" href="/artist_gallery/gallery_kshetra.php" title="Go to this Artist gallery">Watch the gallery <b class="fa-angle-right"></b></a>
				</div>
			</div>
		</article>
	</section><!-- END Articles List col-2 -->
</main><!-- END Main content -->

<!-- footer -->
<?php include ("../include/footer.php")?>