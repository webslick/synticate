<div id="conf_popap" class="confirm-popap-wrap dn">
	<div class="confirm-popap">
		<div class="conf-title">Confirm deletion</div>
		<div class="conf-btn flex sb">
			<span class="conf-ok">Yes</span>
			<span class="conf-no" onclick="javascript: $('#conf_popap').hide()">Cancel</span>
		</div>
	</div>
</div><!-- END Confirm popap -->	