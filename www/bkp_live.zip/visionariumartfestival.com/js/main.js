
// Паралакс эффект на главной
$(document).ready(function(){
	$window = $(window);
	$('div[data-type="background"]').each(function(){
	var $bgobj = $(this);
		$(window).scroll(function() {
        	var yPos = -($window.scrollTop() / $bgobj.data('speed')); 
        	var coords = -yPos + 'px';
			//var coords = '50% '+ yPos + 'px';
			//$bgobj.css({ backgroundPosition: coords });
			
			var currentScroll = $(window).scrollTop();
			var perc = (jQuery('#bg_fixed').height()-$(window).height())*100/jQuery('#bg_fixed').height();
console.log(perc+' - '+currentScroll+' - '+jQuery('#bg_fixed').height()*perc/100);
			if (perc<0 || currentScroll < (jQuery('#bg_fixed').height()*perc/100)) {
				var coords = (0-(currentScroll*.25))+'px';
				console.log('Paralax='+coords);
				
				$bgobj.css( 'top', coords );
			} else {
				$('#bg_fixed').css({
				position: 'fixed',
				top: -(jQuery('#bg_fixed').height()*perc/100),
				left: '0'
        		});

			}
    	})
	}); 
}); 


// Фиксация шапки
jQuery(function($) {
	"use strict";
	var $window = $(window);
	
	var $stickyHeader = $('#navi_fixed'),
		headerHeight = $stickyHeader.outerHeight(),
		menuHeight = 160,
		topPosition = headerHeight - menuHeight,
		headerIsFixed = false;
	
	function addStyles() {		
		$stickyHeader.addClass('navi-fixed');
		$('#body_content').css("marginTop",headerHeight);
		headerIsFixed = true;
	}
	function removeStyles() {
		$stickyHeader.removeClass('navi-fixed');
		$('#body_content').css("marginTop","0");
		headerIsFixed = false;
	}
	if ($window.scrollTop() >= topPosition) {addStyles();}

	$window.scroll(function() {
		if ($window.scrollTop() >= topPosition) {
			if (!headerIsFixed) {addStyles();}
		} else {
			if (headerIsFixed) {removeStyles();}
		}
	});
});

// Mobile menu toogle
// $(document).ready(function(){
// 	$('.mob-menu-icon').on('click', function(e) {
// 		e.preventDefault;
// 		$(this).toggleClass('is-active');
// 	});
// });


// Добавить удалить класс у объектов
// Например: Добавить класс test к объекту pid: show_content('newId','add','show');
// Например: Удалить класс test  объекта pid: show_content('newId','remove','show');
function show_content (id, action, newClass) {
    if (action=='add') {
        if ($("#"+id).hasClass(newClass)) {
            $("#"+id).removeClass(newClass);    
        }
        else {
            $('.show').removeClass('show');
            $("#"+id).addClass(newClass);
        }
    } else {
        $("#"+id).removeClass(newClass);
    }
}
// Закрытие блоков с классом show
$(document).ready(function() {   
    $("body").mouseup(function(e) {
        var subject = $('.show').attr('id');    
        var event_onclick = $(e.target).attr('onClick');
        var parent_event_onclick = $(e.target).parent().attr('onClick');
        var stop_running = 0;
        if (event_onclick) stop_running = event_onclick.indexOf('show_content');
        if (stop_running==0 && parent_event_onclick) stop_running = parent_event_onclick.indexOf('show_content');
        // Определяем где кликнул юзер - по объекту с классом show или мимо
        if(subject && !$(e.target).closest('#'+subject).length && (stop_running==0)) {// мимо, закрываем блок    
            show_content(subject,'remove','show');                           
        }       
    });
});








// Фиксация фона при прокрутке по достижении нижнего края изображения	
$(window).scroll(function() {
    var currentScroll = $(window).scrollTop();
    var perc = (jQuery('#bg_fixed').height()-$(window).height())*100/jQuery('#bg_fixed').height();

	if (perc<=0) {
        $('#bg_fixed').css({
            position: 'fixed',
            top: 0,
            left: '0'
        });	    
    } else {
    if (currentScroll >= jQuery('#bg_fixed').height()*perc/100) {
	    console.log('MYSCROLL = '+perc+' - '+currentScroll+' - '+jQuery('#bg_fixed').height()*perc/100);
	    var paralax_add = currentScroll*.25;
	    console.log('paralax='+paralax_add+' == myscroll='+(jQuery('#bg_fixed').height()*perc/100));
        //$('#bg_fixed').css({
        //    position: 'fixed',
        //    top: -(jQuery('#bg_fixed').height()*perc/100),
        //    left: '0'
        //});
    } else {
        $('#bg_fixed').css({
            position: 'absolute',
            top: '0'
        });
    }
    }
});











// Таймер обратного отсчета
jQuery(document).ready(function() {
	jQuery(".eTimer").eTimer({
		etType: 0, 
		etDate: "17.05.2019.0.0", 
		etTitleText: "Before the event", 
		etTitleSize: 12,
		etShowSign: 2, 
		etSep: ":", 
		etFontFamily: "Arial", 
		etTextColor: "#e4dcdc", 
		etPaddingTB: 5, 
		etPaddingLR: 8,
		etBackground: "rgba(0, 0, 0, 0.55)", 
		etBorderSize: 0, 
		etBorderRadius: 3, 
		etBorderColor: "white", 
		etShadow: "0px 3px 30px -1px #34595c", 
		etLastUnit: 4, 
		etNumberFontFamily:"Impact",
		etNumberSize: 20, 
		etNumberColor: "white", 
		etNumberPaddingTB: 0, 
		etNumberPaddingLR: 1, 
		etNumberBackground: "transparent", etNumberBorderColor: "transparent"
	});
});