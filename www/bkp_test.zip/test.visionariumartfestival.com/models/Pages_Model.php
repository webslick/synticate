<?
class Pages_Model extends Models {
    
    public function get_items( $page, $published=false ) {
        $items = array();
        if( $published != true ) {
            $q_published = " AND `published`=1 ";
        }
        $q_item = $this->query("
            SELECT
                `items`.Id,
                `items`.type,
                `items`.name,
                `items`.content
            FROM
                `pages`,
                `items`
            WHERE
                `items`.pages_id = `pages`.Id
            $q_published
            AND
                `pages`.name='$page'
            ORDER BY
                `items`.sort
            ASC, 
                `items`.Id 
            DESC 
        ");
        while( $item = $q_item->fetch_assoc() ) {
            $q_img = $this->query("
                SELECT 
                    `file_name` AS img
                FROM 
                    `images` 
                WHERE 
                    `items_id`=$item[Id] 
                ORDER BY 
                    `Id` 
                DESC
            ");
            if( $q_img->num_rows > 0 ) {
                while( $images = $q_img->fetch_assoc() ) {
                    $item['img'][] = $images['img'];
                }                
            } else {
                $item['img'][] = 'no_img.jpg';    
            }
            $items[] = $item;
        }
        return $items;
    }
    //==============================================================================
    public function get_item( $id ) {
        $item = $this->query("
            SELECT
                `items`.Id,
                `items`.type,
                `items`.name,
                `items`.content
            FROM
                `items`
            WHERE
                `items`.Id = $id                
        ")->fetch_assoc();
        
        $q_img = $this->query("
            SELECT 
                `file_name` AS img
            FROM 
                `images` 
            WHERE 
                `items_id`=$item[Id] 
            ORDER BY 
                `Id` 
            DESC
        ");
        if( $q_img->num_rows > 0 ) {
            while( $images = $q_img->fetch_assoc() ) {
                $item['img'][] = $images['img'];
            }                
        } else {
            $item['img'][] = 'no_img.jpg';    
        }
        $items[] = $item;
        
        return $items;
    }
    //==============================================================================
    //==============================================================================
    //==============================================================================
    //==============================================================================
    //==============================================================================
    //==============================================================================
}
?>