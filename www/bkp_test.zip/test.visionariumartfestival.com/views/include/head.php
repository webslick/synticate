<!DOCTYPE html>
<html lang="ru">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="title" content="Visionarium Art Festival"> 
	<meta name="description" content="We would like to invite you to a magnificent art event. 
									  Visionarium  art festival- provides  a ground where brightest artists come to 
									  create, exhibit, teach and study together">
	<meta name="keywords" content="art festival, event, visionarium, artists, creature, psychedelic music">
	
	<link rel="shortcut icon" href="/img/favicon.ico"> 
	
	<!-- Общие стили и скрипты -->
	<link rel="stylesheet" href="/fonts/fontello/css/fontello.css">	
	<link rel="stylesheet" href="https://allfont.ru/allfont.css?fonts=ethnocentric" rel="stylesheet">
	
	<link rel="stylesheet" href="/css/common.css">
	<link rel="stylesheet" href="/css/main.css">
	<link rel="stylesheet" href="/css/page.css">
	
	<!-- Главная jquery библиотека -->
	<!-- <script src='https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js'></script> -->	
	<!-- JQUery UI -->
	<!-- <script src="/js/jquery-ui.min.js"></script> -->
    
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    
	<script src="/js/main.js"></script>    
			 
	<!-- Owl carusel -->
	<!-- <script src="/js/jquery_3.3.1.min.js"></script> -->
	<script src="/js/owl.carousel.min.js"></script>	
	<link rel="stylesheet" href="/css/owl.carousel.css">
    
    <? if( $data['user']['admin'] || $data['user']['moder'] ): ?>
    
    <script src="/js/plugins/jquery.ui.touch-punch.min.js"></script>
    <!-- <script src="https://cdn.ckeditor.com/ckeditor5/11.2.0/classic/ckeditor.js"></script> -->
    <script src="https://cdn.ckeditor.com/4.11.2/standard/ckeditor.js"></script>
        
    <!-- <script src="/js/plugins/popup/magnific-popup.min.js"></script>
    <link rel="stylesheet" href="/js/plugins/popup/magnific-popup.css"> -->
    
    <script src="/js/plugins/liteuploader.js"></script>
    <script src="/js/admin.js"></script>
    <? endif ?>

	<!-- Unite gallery carusel -->
	<link rel="stylesheet" href="/css/gallery.css">		
	<link rel='stylesheet' href='/plugins/unitegallery/css/unite-gallery.css'>
	
	<script src='/plugins/unitegallery/js/unitegallery.min.js'></script>	
	<script src='/plugins/unitegallery/themes/tiles/ug-theme-tiles.js'></script>	
		
	<!-- Yandex.Metrika counter -->
	<script type="text/javascript" >
	    (function (d, w, c) {
	        (w[c] = w[c] || []).push(function(){
	            try {
	                w.yaCounter51416728 = new Ya.Metrika2({
	                    id:51416728,
	                    clickmap:true,
	                    trackLinks:true,
	                    accurateTrackBounce:true,
	                    webvisor:true
	                });
	            } catch(e) { }
	        });	
	        var n = d.getElementsByTagName("script")[0],
	            s = d.createElement("script"),
	            f = function () { n.parentNode.insertBefore(s, n);};
	        s.type = "text/javascript";
	        s.async = true;
	        s.src = "https://mc.yandex.ru/metrika/tag.js";
	
	        if (w.opera == "[object Opera]") {
	            d.addEventListener("DOMContentLoaded", f, false);
	        } else { f(); }
	    })(document, window, "yandex_metrika_callbacks2");
	</script>
	
	<noscript>
		<div><img src="https://mc.yandex.ru/watch/51416728" style="position:absolute; left:-9999px"></div>
	</noscript>
	<!-- /Yandex.Metrika counter -->
	
	<!-- Schema -->
	<div class="dn" itemscope="" itemtype="http://schema.org/Organization">
		<meta itemprop="name" content=" «Visionarium Art Festival»">
		<meta itemprop="description" content="We would like to invite you to a magnificent art event Visionarium  art festival">
		<img itemprop="logo" src="/img/logo.png" alt="Logo">
		<link itemprop="url" href="/">	
		<meta itemprop="telephone" content="+7(495) 510-97-83">
		<meta itemprop="email" content="visionariumartfestival@gmail.com">			 
		<div itemprop="address" itemscope itemtype="http://schema.org/PostalAddress">
			<meta itemprop="streetAddress" content="Diseminado Afueras Torrelles de Foix">
			<meta itemprop="postalCode" content="111111">
			<meta itemprop="addressLocality" content="Barcelona, Spane">
		</div>		
	</div>
	
</head>