<?
class Admin_Controller extends Controllers {
    
    public function __construct() {
        parent::__construct( $this->action );
        $this->model = $this->getModel("Admin");
    }
    //==============================================================================
    public function admin_edit() {
        if( $this->is_ajax_request() && $this->user['admin'] || $this->user['moder'] ) {
            $id = $this->ajax['GET']['id'];
            $data = $this->model->get_item_edit( $id );
            $this->tmpl_ajax( "popup/content_add", $data );
        } else {
            $this->__404();
        }
    }
    //==============================================================================
    public function admin_make() {
        if( $this->is_ajax_request() && $this->user['admin'] || $this->user['moder'] ) {
            $last_id = $this->model->make_item( $this->ajax['GET'] );
            if( $last_id ) {
                $last_page = array(
                    'user'=>$this->user,
                    'items'=>$this->getModel("Pages")->get_item( $last_id )
                );
            }
            $this->tmpl_ajax( "page/".$this->ajax['GET']['page'], $last_page );            
        } else {
            $this->__404();
        }    
    }
    //==============================================================================
    public function admin_remove() {
        if( $this->is_ajax_request() && $this->user['admin'] || $this->user['moder'] ) {
            echo $this->model->remove_item( $this->ajax['GET']['id'] );
        } else {
            $this->__404();
        }    
    }
    //==============================================================================
    public function admin_loadimage() {
        if( isset( $_FILES ) && $this->user['admin'] || $this->user['moder'] ) {
            $this->model->load_img( $_POST['item_id'], $_FILES );
        } else {
            $this->__404();
        }
    }
    //==============================================================================
    public function admin_save() {
        if( $this->is_ajax_request() && $this->user['admin'] || $this->user['moder'] ) {

            $link = $this->model->save_item( $this->ajax['POST'] );
            $pages = $this->getModel("Pages");
            $items = $pages->get_items( $link, true );
            $data = array(
                'user'=>$this->user,
                'items'=>$items,
                'link'=>$link
            );
            $this->tmpl_ajax( "page/".$link, $data );
        } else {
            $this->__404();
        }
                    
    }
    //==============================================================================
    public function admin_sort() {
        if( $this->is_ajax_request() && $this->user['admin'] || $this->user['moder'] ) {
            echo $this->model->save_items_sort( $this->ajax['POST'] );
        } else {
            $this->__404();
        }    
    }
    //==============================================================================
    //===============================    USERS   ===================================
    //==============================================================================
    public function admin_users() {
        if( $this->is_ajax_request() && $this->user['admin'] ) {
            $this->tmpl_ajax( "popup/list_admin", $this->model->list_admin() );
        } else {
            $this->__404();
        }
    }    
    //==============================================================================
    public function admin_saveuser() {
        if( $this->is_ajax_request() && $this->user['admin'] ) {            
            $this->model->save_user_data( $this->ajax['POST'] );
        } else {
            $this->__404();
        }
    }
    //==============================================================================
    public function admin_removeuser() {
        if( $this->is_ajax_request() && $this->user['admin'] ) {            
            $this->model->removeuser( $this->ajax['POST']['Id'] );
        } else {
            $this->__404();
        }
    }
    //==============================================================================
    public function admin_toggleroot() {
        if( $this->is_ajax_request() && $this->user['admin'] ) {
            $this->model->toggleroot( $this->ajax['POST']['Id'] );
        } else {
            $this->__404();
        }
    }
    //==============================================================================
}
?>