<?php
class Index_Controller extends Controllers {
    public function init() {        
        $this->tmpl("page/index", $data );
    }
}