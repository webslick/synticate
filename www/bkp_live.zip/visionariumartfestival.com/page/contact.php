<!-- Head -->
<?php include ("../include/head.php"); ?>

<!-- Header -->
<?php include ("../include/header_page.php"); ?>

<!-- Main content -->	
<main class="content-page animate third_bottom">
	<h1 class="page-h1">Contact Page</h1>
	
	<!-- Contacts -->
	<div class="contacts-link block-info">
		<div class="c-link-block">
			<a class="link-name" href="https://www.facebook.com/visionariumgallery/" title="Follow the link" target="_blank">Our page on Facebook</a>
			<a class="link-link" href="https://www.facebook.com/visionariumgallery/" title="Follow the link" target="_blank">www.facebook.com/visionariumgallery</a>
		</div>
		<div class="c-link-block">
			<a class="link-name" href="https://www.facebook.com/Flura.net" title="Follow the link" target="_blank">Our contact email</a>
			<a class="link-link" href="mailto:visionariumfestival@gmail.com" title="Follow the link">visionariumfestival@gmail.com</a>
			<br><br>
		</div>
	</div><!-- END Contacts -->	
	
	<div class="pr tc">
		<!-- Yandex.Metrika informer -->
		<a href="https://metrika.yandex.ru/stat/?id=51416728&amp;from=informer"
		target="_blank" rel="nofollow"><img src="https://informer.yandex.ru/informer/51416728/3_1_FFFFFFFF_EFEFEFFF_0_uniques"
		style="width:88px; height:31px; border:0;" alt="Яндекс.Метрика" title="Яндекс.Метрика: данные за сегодня (просмотры, визиты и уникальные посетители)" class="ym-advanced-informer" data-cid="51416728" data-lang="ru" /></a>
		<!-- /Yandex.Metrika informer -->
	</div>
</div>


</main><!-- END Main content -->

<!-- footer -->
<?php include ("../include/footer.php"); ?>