<div class="log-in-block">
	<div class="log-user">
		<div class="log-user-avatar">
			<img class="dn" src="/images/users/user_admin_0.jpg" alt="User Avatar" title="Test-admin@gmail.com">
			<img class="d" src="/images/users/user_admin_1.jpg" alt="User Icon">
		</div>
		<div class="log-user-menu admin-menu fa-caret-down">
			<ul class="lu-menu ad-menu">
				<li onClick="javascript: $('#add_content_wrap').show()"><b class="fa-plus"></b> Add content</li>
				<li onClick="javascript: $('#admin_list_wrap').show()"><b class="fa-icon-contact-card"></b> User list</li>
				<li><b class="fa-sign-out"></b> Log out</li>
			</ul>
		</div>		
	</div>			
	<div class="log-in fa-sign-in dn" onClick="javascript: $('#log_form_wrap').show()" title="Log in"></div>
</div>