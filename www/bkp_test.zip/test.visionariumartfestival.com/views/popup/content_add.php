<link rel="stylesheet" href="/css/admin_pages.css">

<div id="add_content_wrap" class="win-modal-wrap fade-up">
	<div id="add_content" class="admin-modal win-modal">
		<span class="fa-close" onclick="javascript: $('#add_content_wrap').hide()" title="Закрыть"></span>
        
		<!-- <span class="modal-tips tip-err">Data Error</span> -->
        
        <? //print_r( $data ) ?>
        
		<?if($data['Id']):?>
        <div class="admin-modal-title">Edit content: #<?=$data['Id']?></div>
        <?else:?>
        <div class="admin-modal-title">Add content</div>
        <?endif;?>
        
		<div class="admin-modal-content" id="<?=$data['Id']?>">
			<div class="content-type flex">
				<span class="c-sign">Select content type</span>                
				<!-- Content 1 col -->
				<input id="col_1" class="c-inp" type="radio" name="col" data-type="col-1" hidden <?if($data['type']=='col-1'):?>checked<?endif?> >
				<label class="c-type col-type-1" for="col_1" title="Контент в одну колонку"></label>
				<!-- Content 2 cols -->
				<input id="col_2" class="c-inp" type="radio" name="col" data-type="col-2" hidden <?if($data['type']=='col-2'):?>checked<?endif?> >
				<label class="c-type col-type-2" for="col_2" title="Контент в две колонки"></label>
			</div>
			<div class="content-title-wrap flex sb">
				<!-- Content Title -->
				<div class="content-title">
					<input class="c-title" type="text" placeholder="Enter title" value="<?=$data['name']?>" >
				</div>
				<div class="content-publ">
					<span class="tips-wrap">
						<span class="tips-text">
							<p>To post content, check this box.</p>
						</span>
					</span>
					<input id="r_box" class="root-box" type="checkbox" hidden <?if($data['published']):?>checked<?endif?> >
					<label class="root-label" for="r_box">Published</label>
				</div>
			</div>
			
            <? //print_r( $data ); ?>
            <div class="col-img-1 content-img load_img">
                <? if( isset( $data['img'] ) ): ?>
				<img class="img_preview" src="<?=$data['img'][0]?>" onclick="$('.fileload').click()">
				<? else: ?>
                <img class="img_preview dn" src="" onclick="$('.fileload').click()">
                <span class="load-img-title" onclick="$('.fileload').click()">Add image  1200 x 600 px</span>
                <? endif; ?>
                <input type="file" class="fileload" onchange="previewFile()" style="display:none;" />
			</div>
			<!-- <div class="col-img-2 content-img">
				<img class="dn" src="" alt="Image">
				<span class="load-img-title">Add image  800 x 450 px</span>
			</div> -->
			
            <div class="content-text-wrap">
				<textarea name="editor" rows="8" placeholder="Description text"><?=$data['content']?></textarea>
			</div>
			<div class="tr">
				<span class="save-btn save" onclick="event_admin(this,'admin/save')">Save <b class="fa-floppy-o"></b></span>
			</div>
		</div>	
	</div>	
</div>

<script>
function previewFile() {
    var file    = document.querySelector('input[type=file]').files[0];
    var reader  = new FileReader();

    reader.onloadend = function () {
        var base64_img = reader.result;
        $(".img_preview").attr("src",base64_img).removeClass("dn");
        $(".load-img-title").hide();
    }

    if (file) {
        reader.readAsDataURL(file);
    }
}

CKEDITOR.replace( 'editor' );
</script>
