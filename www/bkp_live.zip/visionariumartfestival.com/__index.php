<!DOCTYPE html>
<html lang="ru">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="title" content="Visionarium Art Festival"> 
	<meta name="description" content="We would like to invite you to a magnificent art event. 
Visionarium  art festival- provides  a ground where brightest artists come to 
create, exhibit, teach and study together">
	<meta name="keywords" content="art festival, event, visionarium, artists, creature, psychedelic music">
	
	<link rel="shortcut icon" href="/img/favicon.ico">
	
	<!-- Общие стили и скрипты -->
	<link rel="stylesheet" href="/fonts/fontello/css/fontello.css">		
	<link rel="stylesheet" href="https://allfont.ru/allfont.css?fonts=ethnocentric" rel="stylesheet">
	
	<link rel="stylesheet" href="/css/common.css">
	<link rel="stylesheet" href="/css/test_main.css">
	<link rel="stylesheet" href="/css/page.css">
	
	
	<!-- Главная jquery библиотека -->
	<script src='https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js'></script>

	
	<script src="/js/main.js"></script>
	
	<!-- JQUery UI -->
	<script src="../js/jquery-ui.min.js"></script>
	
	<!-- Sliders -->
	<script src="/js/jquery.royalslider.min.js"></script>
			 
	<!-- Owl carusel -->
	<script src="/js/jquery_3.3.1.min.js"></script>	
	<script src="/js/owl.carousel.min.js"></script>	
	<link rel="stylesheet" href="/css/owl.carousel.css">


	<!--<link rel="stylesheet" href="design/css/gallery.css">		
	<link rel='stylesheet' href='/js/unitegallery/css/unite-gallery.css'>
	
	<script src='/js/unitegallery/js/unitegallery.min.js'></script>	
	 <script src='/js/unitegallery/themes/tiles/ug-theme-tiles.js'></script> -->
	
</head>

<body class="main-shad">
	
	<!-- Registration form -->
	<?php include ("include/registration_form.php"); ?>

	<!-- header -->
	<header id="navi_fixed" class="main-page-header animate first_top">
		<!-- Logo -->
		<img class="logo" src="/img/logo.png" alt="Visionarium Art Festival">
		<span class="cat-spain head-text">Catalonia, Spain</span>
		<span class="wel-at head-text">Welcome to</span>
		<span class="may-17 head-text">17-19 May 2019</span>
		<span class="art-ev tc head-text">Art Evolution<br>Feslival</span>
		<span class="log-in fa-sign-in" onClick="javascript: $('#log_form_wrap').show()" title="Авторизация"></span>
		<!-- Navigation -->
		<nav class="main-page-nav">
			<!-- Mob. Menu icon -->
			<button class="nav-toggle mob-menu-icon" onClick="javascript:show_content ('header_fixed','add','show')">
				<span class="bar-top"></span>
				<span class="bar-mid"></span>
				<span class="bar-bot"></span>
			</button>
							
			<span class="main-nav flex sb">
		        <a class="m-nav" href="/page/concept.php">Concept</a>
		        <a class="m-nav" href="/page/lokation.php">Location</a>
		        <a class="m-nav" href="/page/artists.php">Artists</a>
		        <a class="m-nav t-nav pulse" href="" target="_blank">T i c k e t</a>
		        <a class="m-nav" href="/page/music.php">Music</a>
		        <a class="m-nav" href="/page/workshops.php">Workshops</a>
		        <a class="m-nav" href="/page/gallery.php">Gallery</a>
		    </span>
		</nav>
	</header><!-- END header -->
	
	<!-- Main content -->	
	<main class="content-main">	
	    <h1 class="m-page-h1 ">
		    We would like to invite you to a magnificent art event. 
			Visionarium  art festival- provides  a ground where brightest artists come to 
			create, exhibit, teach and study together.
		</h1>
		
		<div style="z-index:1000; position:relative; width:600px; margin:0 auto">
			Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt 
			ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation 
			ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in 	
			reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. 
			Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt 
			mollit animid est laborum.<br><br> 
			
			Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt 
			ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation 
			ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in 	
			reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. 
			Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt 
			mollit animid est laborum.<br><br>
			
			Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt 
			ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation 
			ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in 	
			reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. 
			Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt 
			mollit animid est laborum.<br><br>
			
			Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt 
			ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation 
			ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in 	
			reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. 
			Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt 
			mollit animid est laborum.<br><br>
			
			Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt 
			ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation 
			ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in 	
			reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. 
			Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt 
			mollit animid est laborum.<br><br>
			
			Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt 
			ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation 
			ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in 	
			reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. 
			Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt 
			mollit animid est laborum.<br><br>
			
			Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt 
			ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation 
			ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in 	
			reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. 
			Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt 
			mollit animid est laborum.<br><br>
			
			Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt 
			ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation 
			ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in 	
			reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. 
			Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt 
			mollit animid est laborum.<br><br>
			
			Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt 
			ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation 
			ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in 	
			reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. 
			Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt 
			mollit animid est laborum.<br><br>				
		</div>			
	</main><!-- END Main content -->	
	
	<!-- footer -->
	<div class="timer-to eTimer"></div>
	<footer>
		<div class="footer-wrap tc">
			<span class="footer-contact">
				<a class="f-contact-btn" href="/page/contact.php">Contact</a>
			</span>
		</div>			
	</footer>
	<!-- Background -->
	<div id="bg_fixed" class="bg-img-wrap" data-speed="_1" data-type="_background">
		<img class="main-bg-img" src="/img/bg-full.jpg" alt="Visionarium">
	</div>
<script>	
	$(window).scroll(function() {
    var currentScroll = $(window).scrollTop();
    var perc = (jQuery('#bg_fixed').height()-$(window).height())*100/jQuery('#bg_fixed').height();

	if (perc<=0) {
        $('#bg_fixed').css({
            position: 'fixed',
            top: 0,
            left: '0'
        });	    
    } else {
    if (currentScroll >= jQuery('#bg_fixed').height()*perc/100) {
        $('#bg_fixed').css({
            position: 'fixed',
            top: -(jQuery('#bg_fixed').height()*perc/100),
            left: '0'
        });
    } else {
        $('#bg_fixed').css({
            position: 'absolute',
            top: '0'
        });
    }
    }
});
</script>	
</body>
</html>
	
	
	
	

<!-- Таймер обратного отсчета -->
<script src="https://e-timer.ru/js/etimer.js"></script>		
