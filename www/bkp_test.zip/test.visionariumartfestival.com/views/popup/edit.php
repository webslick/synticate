<style>
.white-popup {
    position: relative;
    background: #FFF;
    padding: 20px;
    width: auto;
    max-width: 35%;
    margin: 20px auto;
    color: #000;
}
.r-form-input textarea{
    background: #597D80;
    border: 1px solid #597D80;
    border-radius: 3px;
    padding: 14px 8px;
    width: 100%;
    font-size: 16px;
    color: #fff;
    transition: .3s;    
}
.r-form-input{
    max-width: 95%;
}
.r-form{
    max-width: 55%;
}
</style>

<div class="r-form win-modal">
    <pre><? //print_r( $data ); ?></pre>
    <h3 class="r-form-title">#<?=$data['Id']?>: <?=$data['name']?></h3>
    
    <input type="file" name="fileUpload" class="fileUpload" style="display:none;" />
    
    <div class="r-form-input">
        <div class="preview">
            <img class="load_img" src="/images/<?=$data['img'][0]?>" width="100" />
        </div>
    
        <input type="text" id="name" value="<?=$data['name']?>" />
        <br /><br />
        <textarea name="editor" id="editor"><?=$data['content']?></textarea>
        <br /><br />
        <button class="r-form-btn save" id="<?=$data['Id']?>">save</button>
    </div>
</div>