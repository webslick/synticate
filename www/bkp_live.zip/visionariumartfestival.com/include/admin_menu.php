<div class="admin-menu fa-caret-down">
	<ul class="ad-menu">
		<li><b class="fa-pencil-square-o"></b> Edit</li>
		<li onClick="javascript: $('#conf_popap').show()"><b class="fa-trash-o"></b> Dell</li>
	</ul>
</div>