﻿    <header>
        <h1>Список пользователей</h1>
    
        <nav class="navbar navbar-default">
            <div class="container-fluid">    
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>

                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav">
                        <li class="active">
                            <a class="popup" href="add/popup"><span class="glyphicon glyphicon-plus" aria-hidden="true"></span>&nbsp;Добавить</a>
                        </li>
                    </ul>
                
                    <form id="filter_email" class="navbar-form navbar-left">
                        <div class="form-group">
                            <input type="text" name="email" class="form-control" placeholder="Email">
                        </div>
                        <button type="submit" class="btn btn-default">OK</button>
                    </form>
                </div>    
            </div>
        </nav>
                
    </header>
    
    <div class="section body">
    <table class="table table-bordered">
        <tr>
            <td><strong>#id</strong></td>
            <td><strong>Логин</strong></td>
            <td><strong>E-mail</strong></td>
            <td><strong>Статус</strong></td>
            <td><strong>Действия</strong></td>
        </tr>
        <? 
        foreach( $data['items'] as $item ) { 
            if( $item['status'] ) {
                $status = array( 'Включен', 'Выключить' );
            } else {
                $status = array( 'Выключен', 'Включить' );
            }    
        ?>
        <tr id="<?=$item['Id']?>">
            <td><?=$item['Id']?></td>
            <td><?=$item['login']?></td>
            <td><?=$item['email']?></td>
            <td><?=$status[0]?></td>
            <td>
                <a class="popup edit" href="edit/popup/<?=$item['Id']?>">
                    <span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>
                    &nbsp;Редактировать
                </a>&nbsp;
                <a class="controls toggle" href="status/statustoggle/<?=$item['Id']?>">
                    <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
                    &nbsp;<?=$status[1]?>
                </a>&nbsp;
                <a class="controls remove" href="remove/removeuser/<?=$item['Id']?>">
                    <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
                    &nbsp;Удалить
                </a>
            </td>
        </tr>
        <? } ?>
    </table>
    
    <?
    $page = $data['pagin']['page'];
    $total = $data['pagin']['total'];
    if( !empty( $data['email'] ) ){
        $filter_email = "/".$data['email'];    
    }
    ?>
    
    <nav aria-label="Page navigation">
        <ul class="pagination">
            <? if( $page != 1 ) { ?>
            <li>
                <a href="/p/1<?=$filter_email?>" aria-label="Previous">
                    <span aria-hidden="true">&laquo;&laquo;</span>
                </a>
            </li>
            <li>
                <a href="/p/<?=($page - 1).$filter_email?>" aria-label="Previous">
                    <span aria-hidden="true">&laquo;</span>
                </a>
            </li>
            <? } ?>
            
            <!-- -->
            
            <? if( $page - 2 > 0 ) { ?>
                <li><a href="/p/<?=($page - 2).$filter_email?>"><?=($page - 2)?></a></li>
            <? } ?>
            <? if( $page - 1 > 0 ) { ?>
                <li><a href="/p/<?=($page - 1).$filter_email?>"><?=($page - 1)?></a></li>
            <? } ?>
            
            <!-- -->
            <li class="active"><a href="#"><?=$page?><span class="sr-only">(current)</span></a></li>
            <!-- -->
            
            <? if( $page + 1 <= $total ) { ?>
                <li><a href="/p/<?=($page + 1).$filter_email?>"><?=($page + 1)?></a></li>
            <? } ?>
            <? if( $page + 2 <= $total ) { ?>
                <li><a href="/p/<?=($page + 2).$filter_email?>"><?=($page + 2)?></a></li>
            <? } ?>        
            
            <!-- -->
            
            <? if ( $page != $total ) { ?>
            <li>
                <a href="/p/<?=($page + 1).$filter_email?>" aria-label="Next">
                    <span aria-hidden="true">&raquo;</span>
                </a>
            </li>
            <li>
                <a href="/p/<?=$total.$filter_email?>" aria-label="Next">
                    <span aria-hidden="true">&raquo;&raquo;</span>
                </a>
            </li>
            <? } ?>
        </ul>
    </nav>
    
    
    </div>