<?php
class Pages_Controller extends Controllers {
    private $admin;
    public $action;
    
    public function __construct($action) {
        parent::__construct($action);
        if( $this->user['admin'] || $this->user['moder'] ){
            $this->admin = true;
            $this->action = $action;
        }
    }

    public function concept() {
        $model = $this->getModel("Pages");
        $items = $model->get_items( $this->action[0], $this->admin );
        $data = array(
            'user'=>$this->user,
            'items'=>$items,
            'link'=>$this->action[0]
        );
        $this->tmpl( "page/".$this->action[0], $data );
    }
    //==============================================================================
    public function location() {
        $this->tmpl( "page/".$this->action[0], $data );
    }
    //==============================================================================
    public function artists() {
        $model = $this->getModel("Pages");
        $items = $model->get_items( $this->action[0], $this->admin );
        $data = array(
            'user'=>$this->user,
            'items'=>$items,
            'link'=>$this->action[0]
        );
        $this->tmpl( "page/".$this->action[0], $data );
    }
    //==============================================================================
    public function music() {
        $this->tmpl( "page/".$this->action[0], $data );
    }
    //==============================================================================
    public function workshops() {
        $this->tmpl( "page/".$this->action[0], $data );
    }
    //==============================================================================
    public function gallery() {
        $this->tmpl( "page/".$this->action[0], $data );
    }
    //==============================================================================
    public function contact() {
        $this->tmpl( "page/".$this->action[0], $data );    
    }
    //==============================================================================
}