<!-- Head -->
<?php //include ("../include/head.php"); ?>

<!-- Header -->
<?php //include ("../include/header_page.php"); ?>

<!-- Main content -->	
<main class="content-page animate third_bottom">		
    <h1 class="page-h1">Music</h1>
	
	<!-- Artist Big ban_1 -->
	<section class="article-wrap col-1">
		<!-- Artist_1 -->
		<article class="article-item art-col-1">
			<div class="art-img-block">
				<img src="/images/music/music-main-img3.jpg">
			</div>
			<div class="art-text-block">	
				<p>The music is an accompaniment for workshops, lectures, and art to happen. 
			    	It is there to create an ambient and calm creative atmosphere.  
					The musical concept will follow the line in such styles as Ethnic music, 
					instrumental, psy chill, ambient, psy Dab, downtempo Psybient.
					From 20.00-00.00 concerts and live performances, you may find
					on the Stage and around.</p>
			</div>
		</article>
	</section><!-- END Artist Big ban_1 -->
	
	<!-- Artists List -->
	<section class="article-wrap col-2">
		<!-- Artist_1 -->
		<article class="article-item art-col-2">
			<h2>Free Vibration</h2> 
			<div class="art-img-block">
				<img src="/images/music/free-vibration.jpg">
			</div>
			<div class="art-text-block">
				<img class="scl-icon" src="/img/soundcloud-icon.png" alt="soundcloud-icon">	
				<a class="scl-link" href="https://soundcloud.com/free-vibration" target="_blank">soundcloud.com/Free-vibration</a>
			</div>	
		</article>
		<!-- Artist_2 -->
		<article class="article-item art-col-2">
			<h2>Kukan Dub Lagan</h2> 
			<div class="art-img-block">
				<img src="/images/music/Kukan-dub-lagan.jpg">
			</div>
			<div class="art-text-block">
				<img class="scl-icon" src="/img/soundcloud-icon.png" alt="soundcloud-icon">	
				<a class="scl-link" href="https://soundcloud.com/kukan-dub-lagan" target="_blank">soundcloud.com/Kukan-dub-lagan</a>
			</div>	
		</article>			
		<!-- Artist_2 -->
		<article class="article-item art-col-2">
			<h2>Dj Apel</h2> 
			<div class="art-img-block">
				<img src="/images/music/Apel.jpg">
			</div>
			<div class="art-text-block">
				<img class="scl-icon" src="/img/soundcloud-icon.png" alt="soundcloud-icon">	
				<a class="scl-link" href="https://soundcloud.com/pablo-demunges" target="_blank">soundcloud.com/Dj-Apel</a>
			</div>
		</article>					
		<!-- Artist_3 -->
		<article class="article-item art-col-2">
			<h2>Dj Govinda</h2> 
			<div class="art-img-block">
				<img src="/images/music/Govinda.jpg">
			</div>
			<div class="art-text-block">
				<img class="scl-icon" src="/img/soundcloud-icon.png" alt="soundcloud-icon">	
				<a class="scl-link" href="https://soundcloud.com/govinda-nightrainbow" target="_blank">soundcloud.com/Govinda-nightrainbow</a>
			</div>	
		</article>
		<!-- Artist_5 -->
		<article class="article-item art-col-2">
			<h2>Dj Soleye</h2> 
			<div class="art-img-block">
				<img src="/images/music/Loseye.jpg">
			</div>
			<div class="art-text-block">
				<img class="scl-icon" src="/img/soundcloud-icon.png" alt="soundcloud-icon">	
				<a class="scl-link" href="https://soundcloud.com/k-5/dj-soleye-harmonic-festival" target="_blank">soundcloud.com/Dj-Soleye</a>
			</div>	
		</article>
		<!-- Artist_8 -->
		<article class="article-item art-col-2">
			<h2>Prizma</h2> 
			<div class="art-img-block">
				<img src="/images/music/Prizma-Nikolas.jpg">
			</div>
			<div class="art-text-block dn">
				<img class="scl-icon" src="/img/soundcloud-icon.png" alt="soundcloud-icon">	
				<a class="scl-link" href="https://soundcloud.com/" target="_blank">soundcloud.com/Prizmaw</a>
			</div>	
		</article>
		<!-- Artist_9 -->
		<article class="article-item art-col-2">
			<h2>Roda</h2> 
			<div class="art-img-block">
				<img src="/images/music/Roda.jpg">
			</div>
			<div class="art-text-block">
				<img class="scl-icon" src="/img/soundcloud-icon.png" alt="soundcloud-icon">	
				<a class="scl-link" href="https://soundcloud.com/alexander-chekanov/alexander-chekanov-roda-original-mix" target="_blank">soundcloud.com/Roda-original-mix</a>
			</div>	
		</article>
		<!-- Artist_6 -->
		<article class="article-item art-col-2">
			<h2>Dj Marko Mentale</h2> 
			<div class="art-img-block">
				<img src="/images/music/Marko-mentale.jpg">
			</div>
			<div class="art-text-block dn">
				<img class="scl-icon" src="/img/soundcloud-icon.png" alt="soundcloud-icon">	
				<a class="scl-link" href="https://soundcloud.com/govinda-nightrainbow" target="_blank">soundcloud.com/govinda-nightrainbow</a>
			</div>	
		</article>
		<!-- Artist_7 -->
		<article class="article-item art-col-2">
			<h2>Dj Nowerman</h2> 
			<div class="art-img-block">
				<img src="/images/music/Nowerman-DJ-set.jpg">
			</div>
			<div class="art-text-block dn">
				<img class="scl-icon" src="/img/soundcloud-icon.png" alt="soundcloud-icon">	
				<a class="scl-link" href="https://soundcloud.com/govinda-nightrainbow" target="_blank">soundcloud.com/govinda-nightrainbow</a>
			</div>	
		</article>
		<!-- Artist_10 -->
		<article class="article-item art-col-2">
			<h2>Sheffy Oren Bach</h2> 
			<div class="art-img-block">
				<img src="/images/music/Shefy2.jpg">
			</div>
			<div class="art-text-block">
				<img class="scl-icon" src="/img/soundcloud-icon.png" alt="soundcloud-icon">	
				<a class="scl-link" href="https://soundcloud.com/Sheffyorenbach" target="_blank">soundcloud.com/sheffyorenbach</a>
			</div>	
		</article>
	</section>			
</main><!-- END Main content -->


<!-- footer -->
<?php //include ("../include/footer.php"); ?>