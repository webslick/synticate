<!-- Navigating other art galleries -->
<div class="nav-galleries-wrap bl-shad">
	<div class="nav-galleries-title">Galleries of other artists</div>
	<div class="nav-galleries flex">
		<a class="g-link" href="/artist_gallery/gallery_centaurus.php" title="To the artist's gallery"># Centaurus</a>
		<a class="g-link" href="/artist_gallery/gallery_ihtianderson.php" title="To the artist's gallery"># Ihtianderson</a>
		<a class="g-link" href="/artist_gallery/gallery_pronin.php" title="To the artist's gallery"># Andrey Pronin</a>
		<a class="g-link" href="/artist_gallery/gallery_dimorphic.php" title="To the artist's gallery"># Dimorphic</a>
		<a class="g-link" href="/artist_gallery/gallery_silvina.php" title="To the artist's gallery"># Evgenia Silvina</a>
		<a class="g-link" href="/artist_gallery/gallery_luminokaya.php" title="To the artist's gallery"># Luminokaya</a>
		<a class="g-link" href="/artist_gallery/gallery_trootootoo.php" title="To the artist's gallery"># Trootootoo</a>
		<a class="g-link" href="/artist_gallery/gallery_subliquida.php" title="To the artist's gallery"># Subliquida</a>
		<a class="g-link" href="/artist_gallery/gallery_arturaleza.php" title="To the artist's gallery"># Helena Arturaleza</a>
		<a class="g-link" href="/artist_gallery/gallery_hoffman.php" title="To the artist's gallery"># Martina Hoffman</a>
		<a class="g-link" href="/artist_gallery/gallery_mathieu.php" title="To the artist's gallery"># Mathieu</a>
		<a class="g-link" href="/artist_gallery/gallery_pineal.php" title="To the artist's gallery"># Pineal</a>			
		<a class="g-link" href="/artist_gallery/gallery_drawbot.php" title="To the artist's gallery"># Jeff Drawbot</a>
		<a class="g-link" href="/artist_gallery/gallery_kshetra.php" title="To the artist's gallery"># Kshetra</a>		
	</div>
</div>