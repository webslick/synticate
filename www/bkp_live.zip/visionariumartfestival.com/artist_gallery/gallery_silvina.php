<!-- Head -->
<?php include ("../include/head.php");?>

<!-- Header -->
<?php include ("../include/header_page.php");?>

<!-- Main content -->	
<main class="content-page animate third_bottom">		
    <h1 class="page-h1">Gallery Evgenia Silvina</h1>
	<!-- Gallery -->
	<div class="gallery-wrap">
		<div id="prod_grid">
			<? $files = glob("../images/artist_gallery/gallery_Silvina/*.*");
				for ($i=1; $i<count($files); $i++) {
					?>
						<img src="<?=$files[$i]?>" data-image="<?=$files[$i]?>" data-description="" style="display:none">
					<?
				} 
			?>
		</div>
	</div>
	<!-- Galleryes Menu -->
	<?php include ("../include/galleris_menu.php");?>
</main><!-- END Main content -->


<!-- footer -->
<?php include ("../include/footer.php");?>