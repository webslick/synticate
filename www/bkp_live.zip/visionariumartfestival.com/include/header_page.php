<body class="page-shad">
	<!-- header -->						
	<header id="navi_fixed" class="page-header animate first_top" data-parallax="scroll">
		<a class="logo page-logo" href="/" title="Main page link">
			<img src="/img/logo.png" alt="Visionarium Art Festival">
		</a>
<!--
		<span class="cat-spain head-text">Catalonia, Spain</span>
		<span class="wel-at head-text">Welcome to</span>
		<span class="may-17 head-text">17-19 May 2019</span>
		<span class="art-ev tc head-text">Art Evolution<br>Festival</span>
-->
		
		<!-- Login menu -->
		<?php include ("../include/log_in.php")?>
			
		<!-- Navigation -->
		<nav id="navi" class="page-navi">
			<!-- Mob. Menu icon -->
			<button class="nav-toggle mob-menu-icon" onClick="javascript:show_content ('navi','add','show')">
				<span class="bar-top"></span>
				<span class="bar-mid"></span>
				<span class="bar-bot"></span>
			</button>
			
			<span class="main-nav flex sb">
		        <a class="m-nav <?if ($_SERVER['SCRIPT_NAME']=='/page/concept.php') {?>act<?}?>" href="/page/concept.php">Concept</a>
		        <a class="m-nav <?if ($_SERVER['SCRIPT_NAME']=='/page/lokation.php') {?>act<?}?>" href="/page/lokation.php">Location</a>
		        <a class="m-nav <?if ($_SERVER['SCRIPT_NAME']=='/page/artists.php') {?>act<?}?>" href="/page/artists.php">Artists</a>
		        <a class="m-nav t-nav pulse" href="https://www.hadra.net/tickets/index.php?event_id=17&&lang=2&fbclid=IwAR2MFhGQkQgyyf8JaRT7ZpZO08_dpjZM1cLnAUunPssidDvHPORIjuNMB5Q" target="_blank" onclick="yaCounter51416728.reachGoal ('buy_ticket'); return true;">T i c k e t</a>
		        <a class="m-nav <?if ($_SERVER['SCRIPT_NAME']=='/page/music.php') {?>act<?}?>" href="/page/music.php">Music</a>
		        <a class="m-nav <?if ($_SERVER['SCRIPT_NAME']=='/page/workshops.php') {?>act<?}?>" href="/page/workshops.php">Workshops</a>
			<!-- <a class="m-nav" href="/page/program.php">Program</a> -->
		        <a class="m-nav <?if ($_SERVER['SCRIPT_NAME']=='/page/gallery.php') {?>act<?}?>" href="/page/gallery.php">Gallery</a>
		    </span>
		</nav>
	</header><!-- END header -->
		
	<!-- Registration form -->
	<?php include ("../include/registration_form.php")?>
					
	<!--  Modal Add content -->
	<?php include ("../include/add_content.php")?>
	
	<!-- Modal User list -->
	<?php include ("../include/admin_list.php")?>
	
	<!-- Popap Confirm -->
	<?php include ("../popap/confirm_popap.php")?>	
	