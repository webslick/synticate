<!-- Head -->
<?php //include ("../include/head.php"); ?>

<!-- Header -->
<?php //include ("../include/header_page.php"); ?>

<!-- Main content -->	
<main class="content-page animate third_bottom">		
    <h1 class="page-h1">Workshop</h1>
    <!-- Artist Big ban_1 -->
	<section class="article-wrap col-1 rise block-up">
		<!-- Big ban_1 -->
		<article class="article-item art-col-1">
			<h2>Workshop area</h2> 
			<div class="art-text-block">	
				<p>Workshop area - It is the place where art is born, collaboration or solo live art painting.
					In the workshop area, you can find the most interesting program for those who want to learn,
					there will be taught varied art techniques, pottery, art lessons, lectures and presentation
					of year study programs at different art schools and Academies.</p>
				<p>Presentation of “The Vienna Academy of Visionary Art” Led by Laurence Caruana and Florence 
					Menard which are unique for their approach Each class is taught by skilled professionals 
					who transmit their value of craft while sharing insights into the artist’s vocation.</p>
				<p>At the heart of our programme is the painter’s quest for Original Vision, expressed
					in a unique and refined manner. By promoting cultural ideals of craftsmanship, beauty,
					and style, we celebrate the individual emergence of creativity and genius.</p>
				<p>Laurence Caruana - Lecture - The History of Visionary Art And Figure Drawing, Oil techniques.</p>		
				<p>IhtiAnderson- Platonic shapes workshop, UV Art 3D painting on Black Background. 
					Ebrew The Golden Ratio Perspective</p>
				<p>Artist workshop ticket will allow Full participation in all the workshops on the Festival 
					grounds - VR experience, Oil, figure drawing, the golden cut( Ratio), perspective, 
					UV acrylic painting - creation of 3D objects in your own space, platonic shapes - building
					with sticks and Ebru technique.</p>
			</div>
		</article>
	</section><!-- END Artist Big ban_1 -->

	<!-- Articles List -->
	<section class="article-wrap col-1">
		<!-- Gallery -->
		<div id="prod_grid" class="unite-gallery-wrap">
			<? $files = glob("/images/workshops/*.*");
				for ($i=1; $i<count($files); $i++) {
					?>
						<img src="<?=$files[$i]?>" data-image="<?=$files[$i]?>" data-description="" style="display:none">
					<?
				} 
			?>
		</div>	
	</section><!-- END Articles List -->

</main><!-- END Main content -->

<!-- footer -->
<?php //include ("../include/footer.php"); ?>