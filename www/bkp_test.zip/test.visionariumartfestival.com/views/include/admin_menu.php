<div class="admin-menu fa-caret-down">
	<ul class="ad-menu">
		<li><b class="fa-pencil-square-o"></b> Edit</li>
		<li><b class="fa-trash-o"></b> Dell</li>
	</ul>
</div>