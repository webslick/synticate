<strong>error 404</strong>
<pre><? print_r($data) ?></pre>