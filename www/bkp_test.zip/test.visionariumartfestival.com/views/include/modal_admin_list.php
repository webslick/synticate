<div id="admin_list_wrap" class="user-list-wrap win-modal-wrap fade-up" style="display:none">
	<div id="admin_list" class="r-form win-modal">
		<span class="fa-close" onclick="javascript: $('#admin_list_wrap').hide()" title="Закрыть"></span>
		<div class="r-form-title">Admin list</div>
	

	</div>
</div>


<script>
	// Move modal window
	$(function() {
		$("#admin_list").draggable();
	});
</script>
